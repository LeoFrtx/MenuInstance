-- ============================================================
--  client/events.lua  –  Événements réseau client
-- ============================================================

-- Déclenché par le serveur après chaque mutation d'instance
RegisterNetEvent('instance:refreshDashboard', function()
    lib.callback('instance:getData', false, function(result)
        if not result then return end
        SendNUIMessage({
            type          = 'updateDashboard',
            instances     = result.tempInstances,
            counts        = result.counts,
            currentBucket = result.current,
        })
    end)
end)

return {}