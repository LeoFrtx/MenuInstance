-- ============================================================
--  client/main.lua  –  Point d'entrée client
-- ============================================================

require('client/events')
local Menus = require('client/menus')

-- ── Hash djb2 (miroir de server/utils.lua) ───────────────────
-- Le code est hashé ICI avant d'être envoyé au serveur.
-- Le serveur ne reçoit jamais le code en clair.

local function hashCode(code)
    local h = 5381
    for i = 1, #code do
        h = ((h * 33) ~ string.byte(code, i)) & 0xFFFFFFFF
    end
    return tostring(h)
end

-- ── Helpers ──────────────────────────────────────────────────

local function nuiFocus(state)
    SetNuiFocus(state, state)
end

local function nuiInput(title, fields, cb)
    nuiFocus(false)
    local input = lib.inputDialog(title, fields)
    nuiFocus(true)
    if input then cb(input) end
end

-- ── NUI Callbacks ────────────────────────────────────────────

RegisterNUICallback('enableMouse', function(_, cb)
    nuiFocus(true)
    cb('ok')
end)

RegisterNUICallback('disableMouse', function(_, cb)
    nuiFocus(false)
    cb('ok')
end)

RegisterNUICallback('closeDashboard', function(_, cb)
    Menus.closeDashboard()
    cb('ok')
end)

RegisterNUICallback('refreshDashboard', function(_, cb)
    lib.callback('instance:getData', false, function(result)
        if not result then cb('error') return end
        SendNUIMessage({
            type          = 'updateDashboard',
            instances     = result.tempInstances,
            counts        = result.counts,
            currentBucket = result.current,
        })
        cb('ok')
    end)
end)

-- Retourne la liste des joueurs d'un bucket au dashboard
RegisterNUICallback('getPlayersInBucket', function(data, cb)
    local bucket = tonumber(data.bucket)
    lib.callback('instance:getPlayers', false, function(players)
        cb(players or {})
    end, bucket)
end)

RegisterNUICallback('joinInstance', function(data, cb)
    cb('ok')
    local bucket = tonumber(data.bucket)

    if bucket == 0 then
        TriggerServerEvent('instance:set', 0)
        return
    end

    nuiInput('Accès instance', {
        { type = 'input', label = "Code d'accès", password = true, required = true },
    }, function(input)
        TriggerServerEvent('instance:joinTemp', bucket, hashCode(input[1]))
    end)
end)

RegisterNUICallback('openCreateInstance', function(_, cb)
    cb('ok')
    nuiInput('Nouvelle instance', {
        { type = 'input',  label = 'Nom',                      required = true },
        { type = 'number', label = 'Limite de joueurs',         min = 1,  max = 64,  default = 5 },
        { type = 'input',  label = "Code d'accès",              password = true, required = true },
        { type = 'number', label = 'Durée de vie (h, 0 = ∞)',  min = 0,  max = 720, default = 24 },
    }, function(input)
        TriggerServerEvent('instance:createTemp', {
            name  = input[1],
            limit = input[2],
            code  = hashCode(input[3]),
            ttl   = input[4],
        })
    end)
end)

RegisterNUICallback('openEditInstance', function(data, cb)
    cb('ok')
    nuiInput('Modifier instance', {
        { type = 'input',  label = 'Nom',                      default = data.name,   required = false },
        { type = 'number', label = 'Limite joueurs',            min = 1,  max = 64,   default = data.limit },
        { type = 'input',  label = 'Nouveau code',              password = true,       required = false },
        { type = 'number', label = 'Durée de vie (h, 0 = ∞)',  min = 0,  max = 720,  default = data.ttl or 24 },
    }, function(input)
        local newData = {}
        if input[1] ~= '' and input[1] ~= data.name  then newData.name  = input[1] end
        if input[2] ~= data.limit                     then newData.limit = input[2] end
        if input[3] ~= ''                             then newData.code  = hashCode(input[3]) end
        if input[4] ~= data.ttl                       then newData.ttl   = input[4] end
        if next(newData) then
            TriggerServerEvent('instance:editTemp', data.bucket, newData)
        end
    end)
end)

RegisterNUICallback('clearInstance', function(data, cb)
    cb('ok')
    if data and data.bucket then
        TriggerServerEvent('instance:clear', tonumber(data.bucket))
    end
end)

RegisterNUICallback('deleteInstance', function(data, cb)
    cb('ok')
    if data and data.bucket then
        TriggerServerEvent('instance:deleteTemp', tonumber(data.bucket))
    end
end)

-- ── Commandes ────────────────────────────────────────────────

RegisterCommand('instance', function()
    Menus.openDashboard()
end, false)

RegisterCommand('leaveinst', function()
    if GetPlayerRoutingBucket(PlayerId()) == 0 then
        lib.notify({ title = 'Instance', description = 'Tu es déjà en instance générale', type = 'inform' })
        return
    end
    TriggerServerEvent('instance:set', 0)
end, false)

TriggerEvent('chat:addSuggestion', '/instance', 'Ouvrir le dashboard des instances')
TriggerEvent('chat:addSuggestion', '/leaveinst', 'Quitter l\'instance actuelle')

print('^2[INSTANCES CLIENT]^7 Chargé avec succès!')