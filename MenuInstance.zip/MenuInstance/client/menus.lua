-- ============================================================
--  client/menus.lua  –  Gestion du dashboard NUI
-- ============================================================

local function openDashboard()
    lib.callback('instance:getData', false, function(data)
        if not data then
            lib.notify({ title = 'Instance', description = 'Erreur serveur', type = 'error' })
            return
        end
        SendNUIMessage({
            type          = 'openDashboard',
            instances     = data.tempInstances,
            counts        = data.counts,
            currentBucket = data.current,
            resourceName  = GetCurrentResourceName(),
        })
        SetNuiFocus(true, true)
    end)
end

local function closeDashboard()
    SendNUIMessage({ type = 'closeDashboard' })
    SetNuiFocus(false, false)
end

return {
    openDashboard  = openDashboard,
    closeDashboard = closeDashboard,
}