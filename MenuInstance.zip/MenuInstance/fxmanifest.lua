fx_version 'cerulean'
game 'gta5'

author 'Leo'
description 'Système d\'instances avancé avec invitations et whitelist'
version '2.1.0'

shared_script '@ox_lib/init.lua'

-- Client scripts
client_scripts {
    'client/main.lua',
    'client/menus.lua',
    'client/events.lua'
}

-- Server scripts
server_scripts {
    'server/utils.lua',
    'server/cleanup.lua',
    'server/instances.lua',
    'server/callbacks.lua',
    'server/main.lua'
}

ui_page 'html/dashboard.html'

files {
    'html/dashboard.html'
}