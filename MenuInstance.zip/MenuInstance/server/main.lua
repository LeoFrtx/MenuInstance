-- ============================================================
--  server/main.lua  –  Point d'entrée serveur
-- ============================================================

local U         = require('server/utils')
local Cleanup   = require('server/cleanup')
local Instances = require('server/instances')
require('server/callbacks')

-- ── Chargement initial ───────────────────────────────────────

local instances = Cleanup.load()
print(('^2[INSTANCES]^7 %d instance(s) chargée(s)'):format(U.countInstances(instances)))

-- ── Rate limiting ────────────────────────────────────────────

local rl = {}
local RL_DELAY = {
    set        = 1000,
    createTemp = 3000,
    joinTemp   = 2000,
    deleteTemp = 2000,
    clear      = 2000,
    editTemp   = 2000,
}

local function rateOk(src, action)
    local key   = src .. '_' .. action
    local now   = GetGameTimer()
    local delay = RL_DELAY[action] or 1000

    if rl[key] and (now - rl[key]) < delay then
        U.notify(src, 'Instance', 'Action trop rapide, attends un instant', 'error')
        return false
    end

    rl[key] = now
    return true
end

local function cleanRl(src)
    local prefix = tostring(src) .. '_'
    for key in pairs(rl) do
        if key:sub(1, #prefix) == prefix then rl[key] = nil end
    end
end

-- ── Événements réseau ────────────────────────────────────────

RegisterNetEvent('instance:set', function(bucket)
    local src = source
    if not rateOk(src, 'set') then return end
    Instances.changeInstance(src, bucket, instances)
end)

RegisterNetEvent('instance:createTemp', function(data)
    local src = source
    if not rateOk(src, 'createTemp') then return end
    if type(data) ~= 'table' then return end
    Instances.createInstance(src, data, instances)
end)

RegisterNetEvent('instance:joinTemp', function(bucket, code)
    local src = source
    if not rateOk(src, 'joinTemp') then return end
    if type(code) ~= 'string' then return end
    Instances.joinInstance(src, bucket, code, instances)
end)

RegisterNetEvent('instance:deleteTemp', function(bucket)
    local src = source
    if not rateOk(src, 'deleteTemp') then return end
    Instances.deleteInstance(src, bucket, instances)
end)

RegisterNetEvent('instance:clear', function(bucket)
    local src = source
    if not rateOk(src, 'clear') then return end
    Instances.clearInstance(src, bucket, instances)
end)

RegisterNetEvent('instance:editTemp', function(bucket, newData)
    local src = source
    if not rateOk(src, 'editTemp') then return end
    if type(newData) ~= 'table' then return end
    Instances.editInstance(src, bucket, newData, instances)
end)

-- ── Déconnexion ──────────────────────────────────────────────

AddEventHandler('playerDropped', function()
    local src = source
    Instances.onDisconnect(src, instances)
    cleanRl(src)
end)

-- ── Lifecycle ────────────────────────────────────────────────

AddEventHandler('onServerResourceStop', function(res)
    if res == GetCurrentResourceName() then
        Cleanup.save(instances)
        print('^2[INSTANCES]^7 Arrêt – instances sauvegardées')
    end
end)

-- Auto-cleanup + sauvegarde toutes les heures
SetInterval(function()
    Cleanup.cleanup(instances)
    Cleanup.save(instances)
end, 3600000)

-- ── Exports internes ─────────────────────────────────────────

exports('getTempInstances', function()
    return instances
end)

exports('saveTempInstances', function(data)
    instances = data
    Cleanup.save(instances)
end)

print('^2[INSTANCES]^7 Serveur chargé avec succès!')