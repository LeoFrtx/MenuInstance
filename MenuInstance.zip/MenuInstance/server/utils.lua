-- ============================================================
--  server/utils.lua  –  Fonctions utilitaires serveur
-- ============================================================

local TEMP_START       = 1000
local MAX_TEMP         = 50
local AUTO_DELETE_H    = 24
local MIN_CODE_LEN     = 3
local MAX_NAME_LEN     = 32
local MAX_PLAYER_LIMIT = 64

-- ── Permissions ──────────────────────────────────────────────

local function isAdmin(src)
    return IsPlayerAceAllowed(src, 'instance.admin')
end

-- ── Identifiant stable (license en priorité) ─────────────────

local function getIdentifier(src)
    for i = 0, GetNumPlayerIdentifiers(src) - 1 do
        local id = GetPlayerIdentifier(src, i)
        if id and id:sub(1, 8) == 'license:' then
            return id
        end
    end
    return GetPlayerIdentifier(src, 0)
end

-- ── Hash djb2 ────────────────────────────────────────────────

local function hashCode(code)
    local h = 5381
    for i = 1, #code do
        h = ((h * 33) ~ string.byte(code, i)) & 0xFFFFFFFF
    end
    return tostring(h)
end

-- ── Compteurs ────────────────────────────────────────────────

local function countPlayers(bucket)
    local n = 0
    for _, id in pairs(GetPlayers()) do
        if GetPlayerRoutingBucket(tonumber(id)) == bucket then n += 1 end
    end
    return n
end

local function countInstances(instances)
    local n = 0
    for _ in pairs(instances) do n += 1 end
    return n
end

-- ── Validation ───────────────────────────────────────────────

local function validateData(data)
    if type(data) ~= 'table' then
        return false, 'Données invalides'
    end
    if not data.name or data.name == '' or #data.name > MAX_NAME_LEN then
        return false, ('Nom invalide (1-%d caractères)'):format(MAX_NAME_LEN)
    end
    if not data.limit or data.limit < 1 or data.limit > MAX_PLAYER_LIMIT then
        return false, ('Limite invalide (1-%d joueurs)'):format(MAX_PLAYER_LIMIT)
    end
    if not data.code or #data.code < MIN_CODE_LEN then
        return false, ('Code trop court (min %d caractères)'):format(MIN_CODE_LEN)
    end
    return true
end

-- ── Notifications ────────────────────────────────────────────

local function notify(src, title, desc, ntype)
    TriggerClientEvent('ox_lib:notify', src, {
        title       = title,
        description = desc,
        type        = ntype,
    })
end

local function notifyBucket(bucket, title, desc, ntype)
    for _, id in pairs(GetPlayers()) do
        local pid = tonumber(id)
        if GetPlayerRoutingBucket(pid) == bucket then
            notify(pid, title, desc, ntype)
        end
    end
end

-- ── Dashboard refresh ────────────────────────────────────────

local function refreshFor(src)
    TriggerClientEvent('instance:refreshDashboard', src)
end

return {
    TEMP_START     = TEMP_START,
    MAX_TEMP       = MAX_TEMP,
    AUTO_DELETE_H  = AUTO_DELETE_H,

    isAdmin        = isAdmin,
    getIdentifier  = getIdentifier,
    hashCode       = hashCode,
    countPlayers   = countPlayers,
    countInstances = countInstances,
    validateData   = validateData,
    notify         = notify,
    notifyBucket   = notifyBucket,
    refreshFor     = refreshFor,
}