-- ============================================================
--  server/instances.lua  –  Logique métier des instances
-- ============================================================

local U       = require('server/utils')
local Cleanup = require('server/cleanup')

-- ── Helpers internes ─────────────────────────────────────────

local function canManage(src, inst)
    return U.isAdmin(src) or U.getIdentifier(src) == inst.creatorId
end

local function kickFromBucket(bucket)
    for _, id in pairs(GetPlayers()) do
        local pid = tonumber(id)
        if GetPlayerRoutingBucket(pid) == bucket then
            SetPlayerRoutingBucket(pid, 0)
        end
    end
end

local function transferOwnership(bucket, inst, leavingId)
    for _, id in pairs(GetPlayers()) do
        local pid  = tonumber(id)
        local iden = U.getIdentifier(pid)
        if GetPlayerRoutingBucket(pid) == bucket and iden ~= leavingId then
            inst.createdBy = GetPlayerName(pid)
            inst.creatorId = iden
            U.notify(pid, 'Instance', 'Tu es maintenant owner de l\'instance', 'inform')
            return true
        end
    end
    return false
end

-- ── API publique ─────────────────────────────────────────────

local function changeInstance(src, bucket, instances)
    bucket = tonumber(bucket)
    if not bucket then return end

    if bucket ~= 0 and bucket < U.TEMP_START and not U.isAdmin(src) then
        U.notify(src, 'Instance', 'Accès refusé', 'error')
        return
    end

    SetPlayerRoutingBucket(src, bucket)
    U.notify(src, 'Instance', 'Tu as changé d\'instance', 'success')
    U.refreshFor(src)
end

local function createInstance(src, data, instances)
    if not U.isAdmin(src) then
        U.notify(src, 'Instance', 'Permission refusée', 'error')
        return
    end

    local ok, err = U.validateData(data)
    if not ok then
        U.notify(src, 'Instance', err, 'error')
        return
    end

    if U.countInstances(instances) >= U.MAX_TEMP then
        U.notify(src, 'Instance', 'Limite d\'instances atteinte', 'error')
        return
    end

    local ttl = tonumber(data.ttl)
    if not ttl or ttl < 0 then ttl = U.AUTO_DELETE_H end

    local bucket = U.TEMP_START
    while instances[bucket] do bucket += 1 end

    instances[bucket] = {
        name         = tostring(data.name),
        limit        = tonumber(data.limit),
        codeHash     = data.code,   -- déjà hashé côté client
        ttl          = ttl,
        createdAt    = os.date('%Y-%m-%d %H:%M:%S'),
        createdBy    = GetPlayerName(src),
        creatorId    = U.getIdentifier(src),
        lastActivity = os.time(),
    }

    SetPlayerRoutingBucket(src, bucket)
    Cleanup.save(instances)

    local ttlLabel = ttl == 0 and 'permanente' or ('%dh'):format(ttl)
    U.notify(src, 'Instance créée', ('"%s" créée – expire : %s'):format(data.name, ttlLabel), 'success')
    U.refreshFor(src)
end

local function joinInstance(src, bucket, codeHash, instances)
    bucket = tonumber(bucket)
    local inst = instances[bucket]

    if not inst then
        U.notify(src, 'Instance', 'Instance introuvable', 'error')
        return
    end

    -- Comparaison hash à hash, le code brut n'a jamais transité côté serveur
    if codeHash ~= inst.codeHash then
        U.notify(src, 'Instance', 'Code incorrect', 'error')
        return
    end

    if U.countPlayers(bucket) >= inst.limit then
        U.notify(src, 'Instance', 'Instance pleine', 'error')
        return
    end

    inst.lastActivity = os.time()
    SetPlayerRoutingBucket(src, bucket)
    Cleanup.save(instances)

    local name = GetPlayerName(src)
    for _, id in pairs(GetPlayers()) do
        local pid = tonumber(id)
        if GetPlayerRoutingBucket(pid) == bucket and pid ~= src then
            U.notify(pid, '👤 Nouveau joueur', ('%s a rejoint "%s"'):format(name, inst.name), 'inform')
        end
    end

    U.notify(src, 'Instance', ('Tu as rejoint "%s"'):format(inst.name), 'success')
    U.refreshFor(src)
end

local function deleteInstance(src, bucket, instances)
    bucket = tonumber(bucket)
    local inst = instances[bucket]

    if not inst or bucket < U.TEMP_START then return end

    if not canManage(src, inst) then
        U.notify(src, 'Instance', 'Permission refusée', 'error')
        return
    end

    local instName = inst.name
    U.notifyBucket(bucket, 'Instance', 'L\'instance a été supprimée', 'warning')
    kickFromBucket(bucket)

    instances[bucket] = nil
    Cleanup.save(instances)
    U.notify(src, 'Instance supprimée', ('"%s" supprimée'):format(instName), 'success')
    U.refreshFor(src)
end

local function clearInstance(src, bucket, instances)
    if not U.isAdmin(src) then return end

    bucket = tonumber(bucket)
    if not bucket or bucket == 0 then return end

    U.notifyBucket(bucket, 'Instance', 'Tu as été renvoyé en générale', 'warning')
    kickFromBucket(bucket)

    U.notify(src, 'Instance vidée', 'Tous les joueurs ont été renvoyés en générale', 'success')
    U.refreshFor(src)
end

local function editInstance(src, bucket, newData, instances)
    bucket = tonumber(bucket)
    local inst = instances[bucket]

    if not inst then return end

    if not canManage(src, inst) then
        U.notify(src, 'Instance', 'Permission refusée', 'error')
        return
    end

    if newData.name  and newData.name  ~= '' then inst.name     = newData.name end
    if newData.limit and newData.limit  > 0   then inst.limit    = newData.limit end
    if newData.code  and newData.code  ~= '' then inst.codeHash = newData.code end  -- déjà hashé côté client
    if newData.ttl   and newData.ttl   >= 0   then inst.ttl      = newData.ttl end

    Cleanup.save(instances)
    U.notify(src, 'Instance modifiée', 'Paramètres mis à jour', 'success')
    U.refreshFor(src)
end

local function onDisconnect(src, instances)
    local iden = U.getIdentifier(src)
    if not iden then return end

    for bucket, inst in pairs(instances) do
        if inst.creatorId == iden then
            transferOwnership(bucket, inst, iden)
        end
    end

    Cleanup.save(instances)
end

return {
    changeInstance  = changeInstance,
    createInstance  = createInstance,
    joinInstance    = joinInstance,
    deleteInstance  = deleteInstance,
    clearInstance   = clearInstance,
    editInstance    = editInstance,
    onDisconnect    = onDisconnect,
}