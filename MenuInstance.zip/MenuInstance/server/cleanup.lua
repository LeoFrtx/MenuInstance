-- ============================================================
--  server/cleanup.lua  –  Persistance JSON + auto-nettoyage
-- ============================================================

local U         = require('server/utils')
local SAVE_PATH = 'instances.json'
local RES       = GetCurrentResourceName()

-- ── Sauvegarde ───────────────────────────────────────────────

local function save(instances)
    local ok, encoded = pcall(json.encode, instances)
    if not ok then
        print('^1[INSTANCES]^7 Erreur encodage JSON : ' .. tostring(encoded))
        return
    end
    if not SaveResourceFile(RES, SAVE_PATH, encoded, -1) then
        print('^1[INSTANCES]^7 Impossible d\'écrire ' .. SAVE_PATH)
    end
end

-- ── Chargement ───────────────────────────────────────────────

local function load()
    local raw = LoadResourceFile(RES, SAVE_PATH)
    if not raw or raw == '' or raw == '[]' then return {} end

    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= 'table' then
        print('^3[INSTANCES]^7 Fichier corrompu – réinitialisation')
        return {}
    end

    local fixed = {}
    for k, v in pairs(data) do
        local nk = tonumber(k)
        if nk and type(v) == 'table' then
            v.lastActivity = tonumber(v.lastActivity) or os.time()
            -- Compatibilité ascendante : instances sans ttl héritent du défaut global
            v.ttl = tonumber(v.ttl) or U.AUTO_DELETE_H
            fixed[nk] = v
        end
    end
    return fixed
end

-- ── Auto-nettoyage ───────────────────────────────────────────
-- Chaque instance a son propre ttl (en heures).
-- ttl = 0 → l'instance ne expire jamais (permanente).

local function cleanup(instances)
    local now     = os.time()
    local removed = 0

    for bucket, inst in pairs(instances) do
        local ttl = tonumber(inst.ttl) or U.AUTO_DELETE_H

        -- ttl = 0 signifie permanente, on skip
        if ttl > 0 then
            local elapsed = (now - (inst.lastActivity or 0)) / 3600

            if elapsed > ttl then
                for _, id in pairs(GetPlayers()) do
                    local pid = tonumber(id)
                    if GetPlayerRoutingBucket(pid) == bucket then
                        SetPlayerRoutingBucket(pid, 0)
                        U.notify(pid, 'Instance', 'L\'instance a expiré et a été supprimée', 'warning')
                    end
                end
                instances[bucket] = nil
                removed += 1
            end
        end
    end

    if removed > 0 then
        print(('^3[INSTANCES]^7 %d instance(s) expirée(s) supprimée(s)'):format(removed))
    end
end

return {
    save    = save,
    load    = load,
    cleanup = cleanup,
}