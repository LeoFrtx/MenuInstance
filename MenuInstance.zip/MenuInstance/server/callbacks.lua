-- ============================================================
--  server/callbacks.lua  –  Callbacks ox_lib + exports publics
-- ============================================================

local U         = require('server/utils')
local Cleanup   = require('server/cleanup')
local Instances = require('server/instances')
local RES       = GetCurrentResourceName()

local function getInstances()
    return exports[RES]:getTempInstances()
end

-- ── Callbacks ────────────────────────────────────────────────

lib.callback.register('instance:getData', function(src)
    local instances = getInstances()

    local counts = {}
    for _, id in pairs(GetPlayers()) do
        local b = GetPlayerRoutingBucket(tonumber(id))
        counts[b] = (counts[b] or 0) + 1
    end

    return {
        current          = GetPlayerRoutingBucket(src),
        counts           = counts,
        isAdmin          = U.isAdmin(src),
        tempInstances    = instances,
        playerName       = GetPlayerName(src),
        playerIdentifier = U.getIdentifier(src),
    }
end)

-- Retourne la liste des joueurs présents dans un bucket donné
lib.callback.register('instance:getPlayers', function(src, bucket)
    if not U.isAdmin(src) then return nil end

    bucket = tonumber(bucket)
    if not bucket then return nil end

    local players = {}
    for _, id in pairs(GetPlayers()) do
        local pid = tonumber(id)
        if GetPlayerRoutingBucket(pid) == bucket then
            players[#players + 1] = {
                name       = GetPlayerName(pid),
                identifier = U.getIdentifier(pid),
                id         = pid,
            }
        end
    end

    return players
end)

-- ── Exports API publics ───────────────────────────────────────

exports('SetPlayerInstance', function(src, bucket)
    if GetPlayerPing(src) > 0 then
        SetPlayerRoutingBucket(src, bucket)
    end
end)

exports('GetPlayerInstance', function(src)
    return GetPlayerRoutingBucket(src)
end)

-- Créer une instance programmatiquement (pour d'autres ressources)
exports('CreateInstance', function(name, limit, code)
    local instances = getInstances()
    local bucket    = U.TEMP_START

    while instances[bucket] do bucket += 1 end

    instances[bucket] = {
        name         = name,
        limit        = limit,
        codeHash     = U.hashCode(code),
        createdAt    = os.date('%Y-%m-%d %H:%M:%S'),
        createdBy    = 'System',
        creatorId    = 'system',
        lastActivity = os.time(),
    }

    Cleanup.save(instances)
    return bucket
end)

return {}